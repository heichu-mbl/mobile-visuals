package com.example.overlayfx

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class FxPanel(private val ctx: Context) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val controls = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var cur = Registry.cats[0]

    private fun tv(t: String, size: Float) = TextView(ctx).apply { text = t; textSize = size; setTextColor(Color.WHITE) }

    fun show(cat: String) {
        cur = cat
        list.removeAllViews()
        Registry.items.filter { it.cat == cat }.forEach { item ->
            list.addView(Switch(ctx).apply {
                text = item.title; setTextColor(Color.WHITE); textSize = 15f
                setPadding(0, dp(6), 0, dp(6))
                isChecked = FxState.isActive(item.id)
                setOnCheckedChangeListener { _, on -> FxState.set(item.id, on) }
            })
        }
    }

    fun refresh() = show(cur)

    private fun slider(label: String, init: Int, onChange: (Int) -> Unit): View {
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(tv(label, 12f), LinearLayout.LayoutParams(dp(100), wrap))
        row.addView(SeekBar(ctx).apply {
            max = 100; progress = init
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(0, wrap, 1f))
        return row
    }

    init {
        controls.addView(slider("Прозрачность", (FxState.alpha * 100).toInt()) {
            FxState.alpha = maxOf(0.1f, it / 100f); OverlayService.instance?.applyAlpha()
        })
        controls.addView(slider("Размер", ((Cfg.scale - 0.5f) / 0.015f).toInt()) { Cfg.scale = 0.5f + it * 0.015f })
        val tabs = LinearLayout(ctx)
        Registry.cats.forEach { cat ->
            tabs.addView(Button(ctx).apply { text = cat; setOnClickListener { show(cat) } })
        }
        controls.addView(HorizontalScrollView(ctx).apply { addView(tabs) })
        show(cur)
    }
}
