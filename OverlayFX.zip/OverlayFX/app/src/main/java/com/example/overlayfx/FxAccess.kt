package com.example.overlayfx

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

// Нужен для двух вещей: окно поверх шторки/навигации (на весь экран) и определение «рабочий стол или нет».
class FxAccess : AccessibilityService() {
    companion object { var instance: FxAccess? = null }

    private var homes: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        homes = packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
        OverlayService.instance?.rebuildFx()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg == packageName) return
        val now = homes.contains(pkg)
        if (now != FxState.onDesktop) { FxState.onDesktop = now; OverlayService.instance?.updateFxVisibility() }
    }

    override fun onInterrupt() {}

    private fun release() {
        if (instance === this) {
            instance = null
            FxState.onDesktop = true
            OverlayService.instance?.rebuildFx()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean { release(); return super.onUnbind(intent) }
    override fun onDestroy() { release(); super.onDestroy() }
}
