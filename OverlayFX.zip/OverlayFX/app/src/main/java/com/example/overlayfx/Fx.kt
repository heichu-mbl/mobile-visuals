package com.example.overlayfx

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.*
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

object Cfg {
    var d = 3f
    var scale = 1f
    lateinit var ctx: Context
}

fun mmss(s: Long): String = String.format("%02d:%02d", s / 60, s % 60)

abstract class Fx {
    abstract fun draw(c: Canvas, dt: Float, w: Int, h: Int)
}

// ---------- Прицелы ----------
class Crosshair(private val kind: Int, private val color: Int) : Fx() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val cx = w / 2f; val cy = h / 2f; val s = Cfg.d * Cfg.scale
        p.color = color; p.strokeWidth = 2f * s; p.style = Paint.Style.STROKE
        when (kind) {
            0 -> { c.drawLine(cx - 12 * s, cy, cx + 12 * s, cy, p); c.drawLine(cx, cy - 12 * s, cx, cy + 12 * s, p) }
            1 -> { p.style = Paint.Style.FILL; c.drawCircle(cx, cy, 3 * s, p) }
            2 -> c.drawCircle(cx, cy, 10 * s, p)
            3 -> { c.drawCircle(cx, cy, 12 * s, p); p.style = Paint.Style.FILL; c.drawCircle(cx, cy, 2 * s, p) }
            4 -> {
                c.drawLine(cx - 16 * s, cy, cx - 5 * s, cy, p); c.drawLine(cx + 5 * s, cy, cx + 16 * s, cy, p)
                c.drawLine(cx, cy - 16 * s, cx, cy - 5 * s, p); c.drawLine(cx, cy + 5 * s, cx, cy + 16 * s, p)
            }
            5 -> { c.drawLine(cx - 9 * s, cy - 9 * s, cx + 9 * s, cy + 9 * s, p); c.drawLine(cx - 9 * s, cy + 9 * s, cx + 9 * s, cy - 9 * s, p) }
            6 -> c.drawRect(cx - 9 * s, cy - 9 * s, cx + 9 * s, cy + 9 * s, p)
            7 -> { c.drawLine(cx - 14 * s, cy, cx + 14 * s, cy, p); c.drawLine(cx, cy, cx, cy + 14 * s, p) }
            8 -> {
                val pa = Path(); pa.moveTo(cx, cy - 11 * s); pa.lineTo(cx + 11 * s, cy)
                pa.lineTo(cx, cy + 11 * s); pa.lineTo(cx - 11 * s, cy); pa.close(); c.drawPath(pa, p)
            }
            else -> {
                val pa = Path(); pa.moveTo(cx, cy - 11 * s); pa.lineTo(cx + 10 * s, cy + 8 * s)
                pa.lineTo(cx - 10 * s, cy + 8 * s); pa.close(); c.drawPath(pa, p)
            }
        }
    }
}

// ---------- Частицы ----------
class PCfg(
    val shape: Int = 0, val count: Int = 100, val vyMin: Float = 40f, val vyMax: Float = 100f,
    val vx: Float = 0f, val rMin: Float = 1.5f, val rMax: Float = 4f, val sway: Float = 0f,
    val tail: Float = 0.03f, val twinkle: Boolean = false,
    val glyphs: List<String> = listOf(""), val color: () -> Int = { Color.WHITE }
)

class Particles(private val cfg: PCfg) : Fx() {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var r: Float, var ph: Float, var col: Int, var g: String)
    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private var lw = 0; private var lh = 0

    private fun spawn(w: Int, h: Int, any: Boolean): P {
        val d = Cfg.d
        var x = Random.nextFloat() * w
        if (cfg.vx > 100f) x -= w / 2f else if (cfg.vx < -100f) x += w / 2f
        val fromBottom = cfg.vyMin < 0f && cfg.vyMax <= 0f
        val y = if (any) Random.nextFloat() * h else if (fromBottom) h + 20f * d else -20f * d
        val vy = cfg.vyMin + Random.nextFloat() * (cfg.vyMax - cfg.vyMin)
        val r = (cfg.rMin + Random.nextFloat() * (cfg.rMax - cfg.rMin)) * d
        return P(x, y, cfg.vx * (0.7f + Random.nextFloat() * 0.6f), vy, r,
            Random.nextFloat() * 6.28f, cfg.color(), cfg.glyphs.random())
    }

    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val d = Cfg.d
        if (w != lw || h != lh) { lw = w; lh = h; ps.clear(); repeat(cfg.count) { ps.add(spawn(w, h, true)) } }
        for (p in ps) {
            p.ph += dt * 2f
            p.x += (p.vx + sin(p.ph) * cfg.sway) * d * dt
            p.y += p.vy * d * dt
            if (p.y > h + 40f * d || p.y < -40f * d || p.x < -w.toFloat() || p.x > w * 2f) {
                val n = spawn(w, h, false); p.x = n.x; p.y = n.y; p.vx = n.vx; p.vy = n.vy; p.col = n.col
            }
            paint.color = p.col
            if (cfg.twinkle) paint.alpha = (Color.alpha(p.col) * (0.2f + 0.8f * (sin(p.ph * 3f) + 1f) / 2f)).toInt()
            when (cfg.shape) {
                0 -> { paint.style = Paint.Style.FILL; c.drawCircle(p.x, p.y, p.r, paint) }
                1 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = p.r
                    c.drawLine(p.x, p.y, p.x - p.vx * d * cfg.tail, p.y - p.vy * d * cfg.tail, paint) }
                2 -> { paint.style = Paint.Style.FILL; c.save(); c.translate(p.x, p.y); c.rotate(p.ph * 50f)
                    c.drawRect(-p.r, -p.r * 0.6f, p.r, p.r * 0.6f, paint); c.restore() }
                3 -> { paint.style = Paint.Style.FILL; paint.textSize = p.r * 4f; c.drawText(p.g, p.x, p.y, paint) }
                else -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f * d; c.drawCircle(p.x, p.y, p.r, paint) }
            }
        }
    }
}

// ---------- Фильтры ----------
class TintFx(private val color: Int) : Fx() {
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) { c.drawColor(color) }
}

class VigFx(private val color: Int, private val inner: Float, private val pulse: Boolean) : Fx() {
    private val p = Paint()
    private var lw = 0; private var lh = 0; private var t = 0f
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        if (w != lw || h != lh) {
            lw = w; lh = h
            val r = hypot(w.toDouble(), h.toDouble()).toFloat() / 2f
            p.shader = RadialGradient(w / 2f, h / 2f, r, intArrayOf(color and 0x00FFFFFF, color),
                floatArrayOf(inner, 1f), Shader.TileMode.CLAMP)
        }
        t += dt
        p.alpha = if (pulse) (255 * (0.65f + 0.35f * sin(t * 4f))).toInt() else 255
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }
}

class BarsFx : Fx() {
    private val p = Paint().apply { color = Color.BLACK }
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        c.drawRect(0f, 0f, w.toFloat(), h * 0.12f, p); c.drawRect(0f, h * 0.88f, w.toFloat(), h.toFloat(), p)
    }
}

class ScanFx : Fx() {
    private val p = Paint().apply { color = Color.argb(45, 0, 0, 0); strokeWidth = Cfg.d }
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val st = 4f * Cfg.d; var y = 0f
        while (y < h) { c.drawLine(0f, y, w.toFloat(), y, p); y += st }
    }
}

// ---------- Сетки и фигуры ----------
class GridFx(private val cols: Int, private val rows: Int, private val cellDp: Float) : Fx() {
    private val p = Paint().apply { color = Color.argb(100, 255, 255, 255); strokeWidth = Cfg.d }
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val fw = w.toFloat(); val fh = h.toFloat()
        if (cellDp > 0f) {
            val st = cellDp * Cfg.d
            var x = st; while (x < fw) { c.drawLine(x, 0f, x, fh, p); x += st }
            var y = st; while (y < fh) { c.drawLine(0f, y, fw, y, p); y += st }
        } else {
            for (i in 1 until cols) { val x = fw * i / cols; c.drawLine(x, 0f, x, fh, p) }
            for (j in 1 until rows) { val y = fh * j / rows; c.drawLine(0f, y, fw, y, p) }
        }
    }
}

class ShapeFx(private val kind: Int) : Fx() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val d = Cfg.d; val fw = w.toFloat(); val fh = h.toFloat(); val s = d * Cfg.scale
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = Color.argb(140, 255, 255, 255)
        when (kind) {
            0 -> { c.drawLine(fw / 2, 0f, fw / 2, fh, p); c.drawLine(0f, fh / 2, fw, fh / 2, p) }
            1 -> { c.drawLine(0f, 0f, fw, fh, p); c.drawLine(0f, fh, fw, 0f, p) }
            2 -> c.drawRect(fw * 0.05f, fh * 0.05f, fw * 0.95f, fh * 0.95f, p)
            3 -> { p.strokeWidth = 10 * d; p.color = Color.argb(70, 80, 180, 255); c.drawRect(0f, 0f, fw, fh, p) }
            4 -> { p.strokeWidth = 6 * d; p.color = Color.argb(200, 255, 255, 255); c.drawRect(0f, 0f, fw, fh, p) }
            5 -> { var x = 0f; var i = 0
                while (x < fw) { c.drawLine(x, 0f, x, if (i % 5 == 0) 18 * d else 9 * d, p); x += 10 * d; i++ } }
            6 -> { var y = 0f; var i = 0
                while (y < fh) { c.drawLine(0f, y, if (i % 5 == 0) 18 * d else 9 * d, y, p); y += 10 * d; i++ } }
            7 -> { // MC классический прицел
                p.style = Paint.Style.STROKE
                p.color = Color.BLACK; p.strokeWidth = 5 * s
                c.drawLine(fw / 2 - 9 * s, fh / 2, fw / 2 + 9 * s, fh / 2, p); c.drawLine(fw / 2, fh / 2 - 9 * s, fw / 2, fh / 2 + 9 * s, p)
                p.color = Color.WHITE; p.strokeWidth = 2 * s
                c.drawLine(fw / 2 - 8 * s, fh / 2, fw / 2 + 8 * s, fh / 2, p); c.drawLine(fw / 2, fh / 2 - 8 * s, fw / 2, fh / 2 + 8 * s, p)
            }
            8 -> { p.color = Color.WHITE; p.strokeWidth = 4 * s
                c.drawLine(fw / 2 - 12 * s, fh / 2, fw / 2 + 12 * s, fh / 2, p); c.drawLine(fw / 2, fh / 2 - 12 * s, fw / 2, fh / 2 + 12 * s, p) }
            9 -> { // хотбар
                val slot = minOf(38 * d, fw / 9.5f); val x0 = (fw - 9 * slot) / 2; val y = fh - slot - 12 * d
                for (i in 0 until 9) {
                    p.style = Paint.Style.FILL; p.color = Color.argb(90, 0, 0, 0)
                    c.drawRect(x0 + i * slot, y, x0 + (i + 1) * slot, y + slot, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = if (i == 0) 4 * d else 2 * d
                    p.color = if (i == 0) Color.WHITE else Color.argb(200, 150, 150, 150)
                    c.drawRect(x0 + i * slot, y, x0 + (i + 1) * slot, y + slot, p)
                }
            }
            10 -> { // сердечки
                p.style = Paint.Style.FILL; p.color = Color.RED; p.textSize = 20 * d; p.textAlign = Paint.Align.CENTER
                val slot = minOf(38 * d, fw / 9.5f); val x0 = (fw - 9 * slot) / 2
                for (i in 0 until 10) c.drawText("♥", x0 + i * slot * 0.9f + 10 * d, fh - slot - 12 * d - 30 * d, p)
            }
            else -> { // XP полоска
                val slot = minOf(38 * d, fw / 9.5f); val x0 = (fw - 9 * slot) / 2; val y = fh - slot - 12 * d - 22 * d
                p.style = Paint.Style.FILL; p.color = Color.argb(150, 0, 0, 0); c.drawRect(x0, y, x0 + 9 * slot, y + 7 * d, p)
                p.color = Color.rgb(120, 230, 40); c.drawRect(x0, y, x0 + 9 * slot * 0.6f, y + 7 * d, p)
            }
        }
    }
}

// ---------- Текст (часы, FPS, таймеры) ----------
class TextFx(private val corner: Int, private val text: (Long) -> String) : Fx() {
    private val t0 = System.currentTimeMillis()
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
    override fun draw(c: Canvas, dt: Float, w: Int, h: Int) {
        val d = Cfg.d; val s = d * Cfg.scale
        tp.textSize = 16 * s
        val str = text(System.currentTimeMillis() - t0)
        val pad = 8 * s; val bw = tp.measureText(str) + pad * 2; val bh = tp.textSize + pad * 2; val m = 12 * d
        val x = when (corner) { 1, 3 -> w - m - bw; 4 -> (w - bw) / 2; else -> m }
        val y = when (corner) { 2, 3 -> h - m - bh - 60 * d; else -> 36 * d }
        c.drawRoundRect(x, y, x + bw, y + bh, 10 * d, 10 * d, bg)
        c.drawText(str, x + pad, y + pad + tp.textSize * 0.8f, tp)
    }
}

// ---------- Реестр: 100 функций ----------
class Item(val id: String, val cat: String, val title: String, val make: () -> Fx)

object Registry {
    val cats = listOf("Прицелы", "Эффекты", "Фильтры", "Инструменты", "Майнкрафт")
    val items = ArrayList<Item>()
    val byId: Map<String, Item> by lazy { items.associateBy { it.id } }

    private fun add(id: String, cat: String, title: String, make: () -> Fx) { items.add(Item(id, cat, title, make)) }
    private fun par(id: String, title: String, c: PCfg) = add(id, "Эффекты", title) { Particles(c) }
    private fun timer(id: String, title: String, sec: Long) = add(id, "Инструменты", title) {
        TextFx(1) { ms -> val left = sec - ms / 1000
            if (left <= 0) (if ((ms / 500) % 2 == 0L) "⏰ 00:00" else "   00:00") else "⏳ " + mmss(left) }
    }

    init {
        // --- Прицелы (30) ---
        val styles = listOf("Плюс", "Точка", "Круг", "Круг + точка", "Плюс с зазором", "Крест X", "Квадрат", "T-образный", "Ромб", "Треугольник")
        val cols = listOf("красный" to Color.RED, "зелёный" to Color.GREEN, "голубой" to Color.CYAN)
        for ((i, sn) in styles.withIndex()) for ((ci, cp) in cols.withIndex())
            add("ch_${i}_$ci", "Прицелы", "$sn · ${cp.first}") { Crosshair(i, cp.second) }

        // --- Эффекты (20) ---
        par("snow", "❄️ Снег", PCfg(count = 120, vyMin = 40f, vyMax = 120f, rMin = 1.5f, rMax = 4.5f, sway = 25f, color = { Color.argb(230, 255, 255, 255) }))
        par("snow2", "❄️ Сильный снегопад", PCfg(count = 260, vyMin = 80f, vyMax = 180f, rMin = 1f, rMax = 4f, sway = 30f, color = { Color.argb(230, 255, 255, 255) }))
        par("blizzard", "🌨 Метель", PCfg(count = 300, vyMin = 150f, vyMax = 300f, vx = -200f, rMin = 1f, rMax = 3f, sway = 40f, color = { Color.argb(220, 235, 245, 255) }))
        par("rain", "🌧 Дождь", PCfg(shape = 1, count = 160, vyMin = 700f, vyMax = 1200f, vx = -40f, rMin = 1f, rMax = 1f, color = { Color.argb(150, 170, 200, 255) }))
        par("storm", "⛈ Ливень", PCfg(shape = 1, count = 300, vyMin = 1000f, vyMax = 1600f, vx = -250f, rMin = 1.2f, rMax = 1.2f, color = { Color.argb(170, 160, 190, 255) }))
        par("confetti", "🎉 Конфетти", PCfg(shape = 2, count = 90, vyMin = 120f, vyMax = 280f, rMin = 3f, rMax = 7f, sway = 30f,
            color = { intArrayOf(Color.RED, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GREEN).random() }))
        par("sparks", "🔥 Искры", PCfg(count = 70, vyMin = -280f, vyMax = -80f, rMin = 1.5f, rMax = 4f, sway = 25f, color = { Color.rgb(255, 120 + Random.nextInt(120), 20) }))
        par("fireflies", "✨ Светлячки", PCfg(count = 40, vyMin = -25f, vyMax = 25f, rMin = 2f, rMax = 4f, sway = 40f, twinkle = true, color = { Color.rgb(220, 255, 90) }))
        par("leaves", "🍂 Листопад", PCfg(shape = 3, count = 30, vyMin = 50f, vyMax = 110f, rMin = 4f, rMax = 6f, sway = 45f, glyphs = listOf("🍂", "🍁")))
        par("sakura", "🌸 Сакура", PCfg(shape = 3, count = 35, vyMin = 40f, vyMax = 90f, rMin = 3.5f, rMax = 5.5f, sway = 40f, glyphs = listOf("🌸")))
        par("stars", "⭐ Звёзды", PCfg(shape = 3, count = 40, vyMin = 10f, vyMax = 30f, rMin = 2f, rMax = 5f, twinkle = true, glyphs = listOf("★"), color = { Color.rgb(255, 240, 150) }))
        par("hearts", "❤️ Сердечки", PCfg(shape = 3, count = 30, vyMin = -150f, vyMax = -60f, rMin = 3f, rMax = 6f, sway = 25f, glyphs = listOf("♥"), color = { Color.rgb(255, 60 + Random.nextInt(80), 120) }))
        par("bubbles", "🫧 Пузыри", PCfg(shape = 4, count = 40, vyMin = -90f, vyMax = -30f, rMin = 4f, rMax = 12f, sway = 20f, color = { Color.argb(180, 170, 230, 255) }))
        par("embers", "🔥 Угольки", PCfg(count = 90, vyMin = -120f, vyMax = -40f, rMin = 1f, rMax = 3f, sway = 15f, twinkle = true, color = { Color.rgb(255, 90 + Random.nextInt(80), 20) }))
        par("matrix", "💻 Матрица", PCfg(shape = 3, count = 70, vyMin = 150f, vyMax = 350f, rMin = 2.5f, rMax = 4f, glyphs = listOf("0", "1", "7", "A"), color = { Color.rgb(0, 255, 90) }))
        par("ash", "🌫 Пепел", PCfg(count = 80, vyMin = 20f, vyMax = 60f, rMin = 1f, rMax = 2.5f, sway = 10f, color = { Color.argb(160, 160, 160, 160) }))
        par("dust", "💨 Пыль", PCfg(count = 60, vyMin = -5f, vyMax = 5f, rMin = 1f, rMax = 2f, sway = 12f, twinkle = true, color = { Color.argb(120, 255, 255, 255) }))
        par("meteors", "☄️ Метеоры", PCfg(shape = 1, count = 6, vyMin = 500f, vyMax = 700f, vx = 600f, rMin = 2f, rMax = 2f, tail = 0.12f, color = { Color.WHITE }))
        par("glitter", "✦ Блёстки", PCfg(shape = 3, count = 50, vyMin = 20f, vyMax = 50f, rMin = 2f, rMax = 4f, twinkle = true, glyphs = listOf("✦"), color = { Color.rgb(255, 215, 0) }))
        par("rainbow", "🌈 Радужные точки", PCfg(count = 80, vyMin = 60f, vyMax = 140f, rMin = 2f, rMax = 5f, sway = 20f,
            color = { Color.HSVToColor(220, floatArrayOf(Random.nextFloat() * 360f, 0.9f, 1f)) }))

        // --- Фильтры (20) ---
        val tints = listOf(
            Triple("night", "🌙 Ночь", Color.argb(90, 0, 0, 60)), Triple("deepnight", "🌑 Глубокая ночь", Color.argb(150, 0, 0, 40)),
            Triple("sepia", "📜 Сепия", Color.argb(70, 112, 66, 20)), Triple("red", "Красный оттенок", Color.argb(60, 255, 0, 0)),
            Triple("green", "Зелёный оттенок", Color.argb(60, 0, 255, 0)), Triple("blue", "Синий оттенок", Color.argb(60, 0, 0, 255)),
            Triple("warm", "Тёплый", Color.argb(50, 255, 150, 0)), Triple("cold", "Холодный", Color.argb(50, 0, 150, 255)),
            Triple("purple", "Фиолетовый", Color.argb(60, 150, 0, 200)), Triple("pink", "Розовый", Color.argb(50, 255, 100, 180)),
            Triple("yellow", "Жёлтый (защита глаз)", Color.argb(50, 255, 255, 0)), Triple("cyan", "Бирюзовый", Color.argb(50, 0, 255, 255)),
            Triple("dim30", "Затемнение 30%", Color.argb(77, 0, 0, 0)), Triple("dim50", "Затемнение 50%", Color.argb(128, 0, 0, 0)),
            Triple("dim70", "Затемнение 70%", Color.argb(179, 0, 0, 0)))
        for ((id, t, col) in tints) add("t_$id", "Фильтры", t) { TintFx(col) }
        add("vig", "Фильтры", "Виньетка") { VigFx(Color.argb(200, 0, 0, 0), 0.55f, false) }
        add("vig2", "Фильтры", "Сильная виньетка") { VigFx(Color.argb(240, 0, 0, 0), 0.3f, false) }
        add("bars", "Фильтры", "🎬 Кино-полосы") { BarsFx() }
        add("scan", "Фильтры", "📺 Строки ЭЛТ") { ScanFx() }
        add("frame", "Фильтры", "Рамка по краю") { ShapeFx(4) }

        // --- Инструменты (20) ---
        val hm = SimpleDateFormat("HH:mm", Locale.getDefault())
        val hms = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val dt = SimpleDateFormat("dd.MM.yyyy EEE", Locale.getDefault())
        add("clock", "Инструменты", "🕒 Часы") { TextFx(0) { hm.format(Date()) } }
        add("clock2", "Инструменты", "🕒 Часы с секундами") { TextFx(0) { hms.format(Date()) } }
        add("date", "Инструменты", "📅 Дата") { TextFx(4) { dt.format(Date()) } }
        add("battery", "Инструменты", "🔋 Заряд батареи") {
            var lastT = 0L; var lvl = 0
            TextFx(1) {
                val n = System.currentTimeMillis()
                if (n - lastT > 5000) {
                    lastT = n
                    val i = Cfg.ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                }
                "🔋 $lvl%"
            }
        }
        add("fps", "Инструменты", "📊 FPS") {
            var frames = 0; var t0 = System.nanoTime(); var shown = 0
            TextFx(0) {
                frames++
                val n = System.nanoTime()
                if (n - t0 >= 1_000_000_000L) { shown = frames; frames = 0; t0 = n }
                "FPS $shown"
            }
        }
        add("stopwatch", "Инструменты", "⏱ Секундомер") { TextFx(1) { ms -> "⏱ " + mmss(ms / 1000) } }
        timer("timer1", "⏳ Таймер 1 мин", 60); timer("timer5", "⏳ Таймер 5 мин", 300)
        timer("timer10", "⏳ Таймер 10 мин", 600); timer("timer15", "⏳ Таймер 15 мин", 900)
        add("grid3", "Инструменты", "Сетка 3×3") { GridFx(3, 3, 0f) }
        add("grid6", "Инструменты", "Сетка 6×6") { GridFx(6, 6, 0f) }
        add("grid12", "Инструменты", "Сетка 12×12") { GridFx(12, 12, 0f) }
        add("gridthin", "Инструменты", "Мелкая сетка 30dp") { GridFx(0, 0, 30f) }
        add("centerl", "Инструменты", "Линии через центр") { ShapeFx(0) }
        add("diag", "Инструменты", "Диагонали") { ShapeFx(1) }
        add("safe", "Инструменты", "Безопасная рамка 5%") { ShapeFx(2) }
        add("rulert", "Инструменты", "Линейка сверху") { ShapeFx(5) }
        add("rulerl", "Инструменты", "Линейка слева") { ShapeFx(6) }
        add("glow", "Инструменты", "Свечение по краям") { ShapeFx(3) }

        // --- Майнкрафт (10) ---
        add("mc_day", "Майнкрафт", "☀️🌙 Цикл дня и ночи (20 мин)") {
            TextFx(4) { ms ->
                val t = (ms / 1000) % 1200
                val (ic, name, left) = when {
                    t < 600 -> Triple("☀️", "День", 600 - t)
                    t < 690 -> Triple("🌆", "Закат", 690 - t)
                    t < 1110 -> Triple("🌙", "Ночь (мобы!)", 1110 - t)
                    else -> Triple("🌅", "Рассвет", 1200 - t)
                }
                "$ic $name · ${mmss(left)}"
            }
        }
        add("mc_cross", "Майнкрафт", "Прицел как в Майнкрафте") { ShapeFx(7) }
        add("mc_cross2", "Майнкрафт", "Толстый белый прицел") { ShapeFx(8) }
        add("mc_grid40", "Майнкрафт", "Сетка блоков (крупная)") { GridFx(0, 0, 40f) }
        add("mc_grid80", "Майнкрафт", "Сетка блоков (очень крупная)") { GridFx(0, 0, 80f) }
        add("mc_hotbar", "Майнкрафт", "Рамка хотбара") { ShapeFx(9) }
        add("mc_xp", "Майнкрафт", "Полоска опыта") { ShapeFx(11) }
        add("mc_hearts", "Майнкрафт", "Сердечки HP") { ShapeFx(10) }
        add("mc_lowhp", "Майнкрафт", "Красный пульс (мало HP)") { VigFx(Color.argb(220, 200, 0, 0), 0.35f, true) }
        add("mc_repeat", "Майнкрафт", "Повтор-таймер 30 с (ферма/рыбалка)") {
            TextFx(1) { ms -> "🔁 " + mmss(30 - (ms / 1000) % 30) }
        }
    }
}
