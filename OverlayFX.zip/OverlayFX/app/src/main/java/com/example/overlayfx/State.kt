package com.example.overlayfx

object FxState {
    val active = LinkedHashMap<String, Fx>()
    var alpha = 1f
    var desktopOnly = false
    var onDesktop = true
    var bubbleOn = true

    fun isActive(id: String) = active.containsKey(id)

    fun set(id: String, on: Boolean) {
        if (on) { if (!active.containsKey(id)) active[id] = Registry.byId[id]!!.make() } else active.remove(id)
        OverlayService.instance?.refresh()
    }

    fun clear() { active.clear(); OverlayService.instance?.refresh() }
}
