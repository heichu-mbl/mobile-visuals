package com.example.overlayfx

import android.content.Context
import android.graphics.Canvas
import android.view.View

class EffectView(ctx: Context) : View(ctx) {
    private val active = LinkedHashMap<String, Fx>()
    private var last = System.nanoTime()

    fun isActive(id: String) = active.containsKey(id)

    fun set(id: String, on: Boolean) {
        if (on) { if (!active.containsKey(id)) active[id] = Registry.byId[id]!!.make() } else active.remove(id)
        last = System.nanoTime()
        postInvalidateOnAnimation()
    }

    fun clear() { active.clear(); invalidate() }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        for (fx in active.values.toList()) fx.draw(c, dt, width, height)
        if (active.isNotEmpty()) postInvalidateOnAnimation()
    }
}
