package com.example.overlayfx

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

class EffectView(ctx: Context, private val mode: String) : View(ctx) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float,
                    var r: Float, var ph: Float, var color: Int)

    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var last = System.nanoTime()
    private val d = resources.displayMetrics.density
    private val confettiColors = intArrayOf(Color.RED, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GREEN, Color.rgb(255,140,0))

    private fun spawn(w: Int, h: Int, anywhere: Boolean): P {
        val x = Random.nextFloat() * w
        val y = if (anywhere) Random.nextFloat() * h else -20f * d
        return when (mode) {
            "rain" -> P(x, y, -40f * d, (700f + Random.nextFloat() * 500f) * d, 1f * d, 0f, Color.argb(150, 170, 200, 255))
            "confetti" -> P(x, y, 0f, (120f + Random.nextFloat() * 160f) * d, (3f + Random.nextFloat() * 4f) * d,
                Random.nextFloat() * 6.28f, confettiColors.random())
            "sparks" -> P(x, if (anywhere) y else h + 20f * d, 0f, -(80f + Random.nextFloat() * 200f) * d,
                (1.5f + Random.nextFloat() * 2.5f) * d, Random.nextFloat() * 6.28f,
                Color.rgb(255, 120 + Random.nextInt(120), 20))
            else -> P(x, y, 0f, (40f + Random.nextFloat() * 80f) * d, (1.5f + Random.nextFloat() * 3.5f) * d,
                Random.nextFloat() * 6.28f, Color.argb(230, 255, 255, 255))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ps.clear()
        val n = when (mode) { "rain" -> 160; "confetti" -> 90; "sparks" -> 70; else -> 130 }
        repeat(n) { ps.add(spawn(w, h, true)) }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        val w = width; val h = height
        for (p in ps) {
            p.ph += dt * 2f
            p.x += (p.vx + if (mode == "snow" || mode == "confetti" || mode == "sparks") sin(p.ph) * 25f * d else 0f) * dt
            p.y += p.vy * dt
            val out = p.y > h + 30f * d || p.y < -40f * d || p.x < -30f * d || p.x > w + 30f * d
            if (out) { val n = spawn(w, h, false); p.x = n.x; p.y = n.y; p.vx = n.vx; p.vy = n.vy }
            paint.color = p.color
            if (mode == "rain") {
                paint.strokeWidth = p.r
                c.drawLine(p.x, p.y, p.x + p.vx * 0.03f, p.y + p.vy * 0.03f, paint)
            } else c.drawCircle(p.x, p.y, p.r, paint)
        }
        postInvalidateOnAnimation()
    }
}
