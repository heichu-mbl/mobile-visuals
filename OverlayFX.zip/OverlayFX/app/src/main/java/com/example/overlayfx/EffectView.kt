package com.example.overlayfx

import android.content.Context
import android.graphics.Canvas
import android.view.View

class EffectView(ctx: Context) : View(ctx) {
    private var last = System.nanoTime()

    fun refresh() { last = System.nanoTime(); postInvalidateOnAnimation() }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        for (fx in FxState.active.values.toList()) fx.draw(c, dt, width, height)
        if (FxState.active.isNotEmpty()) postInvalidateOnAnimation()
    }
}
