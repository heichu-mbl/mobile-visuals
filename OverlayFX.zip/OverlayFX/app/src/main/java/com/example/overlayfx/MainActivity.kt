package com.example.overlayfx

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "OverlayFX\n\nНажми «Запустить» — на экране появится синий кружок FX. Тапни по нему, чтобы открыть меню (100 функций). Кружок можно таскать пальцем."
            textSize = 16f; gravity = Gravity.CENTER
        })
        root.addView(Button(this).apply { text = "▶ Запустить"; setOnClickListener { start("start") } })
        root.addView(Button(this).apply { text = "⏹ Выключить полностью"; setOnClickListener { start("stop") } })
        setContentView(root)
    }

    private fun start(mode: String) {
        if (mode != "stop" && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши «Поверх других приложений»", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java).putExtra("mode", mode)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}
