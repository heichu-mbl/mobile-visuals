package com.example.overlayfx

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply { text = "Эффекты поверх всех приложений"; textSize = 20f; gravity = Gravity.CENTER })
        fun btn(t: String, mode: String) = root.addView(Button(this).apply {
            text = t
            setOnClickListener { start(mode) }
        })
        btn("❄️ Снег", "snow")
        btn("🌧 Дождь", "rain")
        btn("🎉 Конфетти", "confetti")
        btn("🔥 Искры", "sparks")
        btn("⏹ Выключить", "stop")
        setContentView(root)
    }

    private fun start(mode: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши «Поверх других приложений»", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java).putExtra("mode", mode)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}
