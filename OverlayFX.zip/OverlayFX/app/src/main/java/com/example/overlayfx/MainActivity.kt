package com.example.overlayfx

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var panel: FxPanel

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Cfg.init(this)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        panel = FxPanel(this)
        val pad = (16 * Cfg.d).toInt()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        col.addView(TextView(this).apply { text = "OverlayFX"; textSize = 22f; setTextColor(Color.WHITE) })

        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "▶ Запустить"; setOnClickListener { start("start") } }, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(Button(this).apply { text = "⏹ Стоп"; setOnClickListener { start("stop") } }, LinearLayout.LayoutParams(0, wrap, 1f))
        col.addView(row)

        col.addView(Switch(this).apply {
            text = "Кружок FX на экране"; setTextColor(Color.WHITE); isChecked = FxState.bubbleOn
            setPadding(0, pad / 2, 0, pad / 2)
            setOnCheckedChangeListener { _, on -> FxState.bubbleOn = on; OverlayService.instance?.updateBubble() }
        })
        col.addView(Switch(this).apply {
            text = "Только на рабочем столе"; setTextColor(Color.WHITE); isChecked = FxState.desktopOnly
            setPadding(0, pad / 2, 0, pad / 2)
            setOnCheckedChangeListener { v, on ->
                if (on && FxAccess.instance == null) {
                    Toast.makeText(this@MainActivity, "Сначала включи «OverlayFX» в спец. возможностях", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    v.isChecked = false
                    return@setOnCheckedChangeListener
                }
                FxState.desktopOnly = on
                OverlayService.instance?.updateFxVisibility()
            }
        })

        status = TextView(this).apply { textSize = 13f; setTextColor(Color.LTGRAY) }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Полный экран (спец. возможности)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(Button(this).apply { text = "Выкл все эффекты"; setOnClickListener { FxState.clear(); panel.refresh() } })

        col.addView(panel.controls)
        col.addView(panel.list)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.rgb(18, 20, 26)); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (FxAccess.instance != null) "Полный экран: ВКЛ ✅ (поверх шторки и навигации)"
        else "Полный экран: выкл ⚠️ — включи «OverlayFX» в спец. возможностях"
        panel.refresh()
    }

    private fun start(mode: String) {
        if (mode != "stop" && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши «Поверх других приложений»", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java).putExtra("mode", mode)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}
