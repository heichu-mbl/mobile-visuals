package com.example.overlayfx

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs

class BubbleView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = width / 2f
        p.color = Color.argb(230, 40, 120, 255); c.drawCircle(r, r, r - 2, p)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.9f; p.isFakeBoldText = true
        c.drawText("FX", r, r + r * 0.3f, p)
    }
}

class OverlayService : Service() {
    companion object { var instance: OverlayService? = null }

    private lateinit var wm: WindowManager
    private var fxView: EffectView? = null
    private var fxWm: WindowManager? = null
    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * Cfg.d).toInt()

    private val overlayType: Int get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        instance = this
        Cfg.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getStringExtra("mode") == "stop") {
            cleanup(); stopForeground(true); stopSelf(); return START_NOT_STICKY
        }
        startForeground(1, notification())
        if (fxView == null) { addFx(); updateBubble() }
        return START_STICKY
    }

    // ---------- слой эффектов (на весь экран) ----------
    @Suppress("DEPRECATION")
    private fun realSize(m: WindowManager): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = m.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            m.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun addFx() {
        val acc = FxAccess.instance
        val host: Context = acc ?: this
        val mgr = host.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val (w, h) = realSize(mgr)
        val type = if (acc != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else overlayType
        val lp = WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0; lp.y = 0
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            lp.fitInsetsTypes = 0
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val v = EffectView(host)
        v.alpha = FxState.alpha
        mgr.addView(v, lp)
        fxView = v; fxWm = mgr
        updateFxVisibility()
    }

    fun rebuildFx() {
        if (fxView == null) return
        fxView?.let { try { fxWm?.removeView(it) } catch (_: Exception) {} }
        fxView = null; fxWm = null
        addFx()
    }

    fun refresh() { fxView?.refresh() }
    fun applyAlpha() { fxView?.alpha = FxState.alpha }

    fun updateFxVisibility() {
        val vis = !FxState.desktopOnly || FxState.onDesktop
        fxView?.visibility = if (vis) View.VISIBLE else View.INVISIBLE
        if (vis) fxView?.refresh()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeMenu()
        handler.postDelayed({ rebuildFx() }, 400)
    }

    // ---------- кружок ----------
    fun updateBubble() {
        if (FxState.bubbleOn) {
            if (bubble == null && fxView != null) addBubble()
        } else {
            closeMenu()
            bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            bubble = null
        }
    }

    private fun addBubble() {
        val size = dp(50)
        val lp = bubbleLp ?: WindowManager.LayoutParams(size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).also {
            it.gravity = Gravity.TOP or Gravity.START; it.x = dp(8); it.y = dp(160); bubbleLp = it
        }
        val b = BubbleView(this)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > 10 * Cfg.d || abs(my) > 10 * Cfg.d) moved = true
                    if (moved) { lp.x = (sx + mx).toInt(); lp.y = (sy + my).toInt(); wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(); true }
                else -> false
            }
        }
        bubble = b
        wm.addView(b, lp)
    }

    // ---------- меню ----------
    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = buildMenu()
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.94f).toInt(), (dm.heightPixels * 0.6f).toInt(),
            overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(12)
        menu = m
        wm.addView(m, lp)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    private fun buildMenu(): View {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val panel = FxPanel(ctx)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(240, 22, 24, 32)); cornerRadius = dp(18).toFloat() }
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ctx).apply { text = "OverlayFX · 100 функций"; textSize = 16f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        head.addView(Button(ctx).apply { text = "Выкл всё"; setOnClickListener { FxState.clear(); panel.refresh() } })
        head.addView(Button(ctx).apply { text = "✕"; setOnClickListener { closeMenu() } })
        root.addView(head)
        root.addView(panel.controls)
        root.addView(ScrollView(ctx).apply { addView(panel.list) }, LinearLayout.LayoutParams(match, 0, 1f))
        return root
    }

    private fun cleanup() {
        closeMenu()
        fxView?.let { try { fxWm?.removeView(it) } catch (_: Exception) {} }; fxView = null; fxWm = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null
    }

    override fun onDestroy() { cleanup(); instance = null; super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val ch = "fx"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(ch, "Эффекты", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).putExtra("mode", "stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        return b.setContentTitle("OverlayFX работает").setContentText("Нажми, чтобы открыть управление")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop).build()
    }
}
