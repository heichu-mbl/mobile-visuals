package com.example.overlayfx

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    private var view: View? = null
    private val wm get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra("mode") ?: "snow"
        startForeground(1, notification())
        removeView()
        if (mode == "stop") { stopForeground(true); stopSelf(); return START_NOT_STICKY }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or      // касания проходят насквозь
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        view = EffectView(this, mode).also { wm.addView(it, lp) }
        return START_STICKY
    }

    private fun removeView() { view?.let { try { wm.removeView(it) } catch (_: Exception) {} }; view = null }
    override fun onDestroy() { removeView(); super.onDestroy() }

    private fun notification(): Notification {
        val ch = "fx"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(ch, "Эффекты", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).putExtra("mode", "stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("OverlayFX работает").setContentText("Нажми, чтобы выключить")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(stop).build()
    }
}
