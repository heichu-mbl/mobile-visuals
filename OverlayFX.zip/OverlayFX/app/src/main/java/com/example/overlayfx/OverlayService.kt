package com.example.overlayfx

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs

class BubbleView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = width / 2f
        p.color = Color.argb(230, 40, 120, 255); c.drawCircle(r, r, r - 2, p)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.9f; p.isFakeBoldText = true
        c.drawText("FX", r, r + r * 0.3f, p)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var fxView: EffectView? = null
    private var bubble: View? = null
    private var menu: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * Cfg.d).toInt()

    private val overlayType: Int get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getStringExtra("mode") == "stop") {
            cleanup(); stopForeground(true); stopSelf(); return START_NOT_STICKY
        }
        startForeground(1, notification())
        if (fxView == null) setup()
        return START_STICKY
    }

    private fun setup() {
        Cfg.d = resources.displayMetrics.density
        Cfg.ctx = applicationContext
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val fxLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        fxView = EffectView(this).also { wm.addView(it, fxLp) }

        val size = dp(50)
        val lp = WindowManager.LayoutParams(size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(8); lp.y = dp(160)
        val b = BubbleView(this)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > 10 * Cfg.d || abs(my) > 10 * Cfg.d) moved = true
                    if (moved) { lp.x = (sx + mx).toInt(); lp.y = (sy + my).toInt(); wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(); true }
                else -> false
            }
        }
        bubble = b
        wm.addView(b, lp)
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = buildMenu()
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.94f).toInt(), (dm.heightPixels * 0.6f).toInt(),
            overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(12)
        menu = m
        wm.addView(m, lp)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    private fun buildMenu(): View {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val fx = fxView!!
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(240, 22, 24, 32)); cornerRadius = dp(18).toFloat() }
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        fun tv(t: String, size: Float) = TextView(ctx).apply { text = t; textSize = size; setTextColor(Color.WHITE) }

        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        var cur = Registry.cats[0]
        fun show(cat: String) {
            cur = cat
            list.removeAllViews()
            Registry.items.filter { it.cat == cat }.forEach { item ->
                list.addView(Switch(ctx).apply {
                    text = item.title; setTextColor(Color.WHITE); textSize = 15f
                    setPadding(0, dp(6), 0, dp(6))
                    isChecked = fx.isActive(item.id)
                    setOnCheckedChangeListener { _, on -> fx.set(item.id, on) }
                })
            }
        }

        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("OverlayFX · 100 функций", 16f), LinearLayout.LayoutParams(0, wrap, 1f))
        head.addView(Button(ctx).apply { text = "Выкл всё"; setOnClickListener { fx.clear(); show(cur) } })
        head.addView(Button(ctx).apply { text = "✕"; setOnClickListener { closeMenu() } })
        root.addView(head)

        fun slider(label: String, init: Int, onChange: (Int) -> Unit): View {
            val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(label, 12f), LinearLayout.LayoutParams(dp(100), wrap))
            row.addView(SeekBar(ctx).apply {
                max = 100; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, LinearLayout.LayoutParams(0, wrap, 1f))
            return row
        }
        root.addView(slider("Прозрачность", (fx.alpha * 100).toInt()) { fx.alpha = maxOf(0.1f, it / 100f) })
        root.addView(slider("Размер", ((Cfg.scale - 0.5f) / 0.015f).toInt()) { Cfg.scale = 0.5f + it * 0.015f })

        val tabs = LinearLayout(ctx)
        Registry.cats.forEach { cat ->
            tabs.addView(Button(ctx).apply { text = cat; setOnClickListener { show(cat) } })
        }
        root.addView(HorizontalScrollView(ctx).apply { addView(tabs) })

        show(cur)
        root.addView(ScrollView(ctx).apply { addView(list) }, LinearLayout.LayoutParams(match, 0, 1f))
        return root
    }

    private fun cleanup() {
        closeMenu()
        fxView?.let { try { wm.removeView(it) } catch (_: Exception) {} }; fxView = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun notification(): Notification {
        val ch = "fx"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(ch, "Эффекты", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).putExtra("mode", "stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("OverlayFX работает").setContentText("Нажми, чтобы полностью выключить")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(stop).build()
    }
}
