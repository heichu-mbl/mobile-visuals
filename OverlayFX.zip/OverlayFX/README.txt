Сборка APK:
1. Установи Android Studio, File -> Open -> папка OverlayFX, дождись синхронизации.
2. Build -> Build Bundle(s)/APK(s) -> Build APK(s).
   Файл: app/build/outputs/apk/debug/app-debug.apk
3. Установи на телефон, открой, выдай «Поверх других приложений».
Без ПК: залей папку на GitHub и собери через GitHub Actions.
